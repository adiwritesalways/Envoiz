import "./InvoiceTemplate.css";

export interface InvoiceLineItem {
  description: string;
  qty: string;
  price: string;
  subtotal: string;
}

export interface InvoiceData {
  invoiceNumber: string;
  date: string;
  dueDate: string;
  companyName: string;
  companyAddressLines: string[];
  billTo: {
    name: string;
    address: string;
    phone: string;
  };
  paymentMethod: {
    bankName: string;
    accountName: string;
    phone: string;
  };
  items: InvoiceLineItem[];
  emptyRowCount?: number;
  tax: string;
  grandTotal: string;
  termsAndConditions: string;
  contactEmail: string;
  contactPhone: string;
  signerName: string;
  signerTitle: string;
}

const defaultInvoice: InvoiceData = {
  invoiceNumber: "#1234",
  date: "AUGUST 12, 2030",
  dueDate: "SEPTEMBER 12, 2030",
  companyName: "LICERIA & CO.",
  companyAddressLines: ["123 ANYWHERE ST.,", "ANY CITY", "+123-456-7890"],
  billTo: {
    name: "OLIVIA WILSON",
    address: "123 Anywhere st., Any City",
    phone: "+123-456-7890",
  },
  paymentMethod: {
    bankName: "Borcelle Bank",
    accountName: "AVERY DAVIS",
    phone: "+123-456-7890",
  },
  items: [
    { description: "LOGO DESIGN", qty: "05", price: "$200", subtotal: "$1000" },
    { description: "PACKAGING DESIGN", qty: "04", price: "$300", subtotal: "$1200" },
    { description: "POSTER DESIGN", qty: "10", price: "$150", subtotal: "$1500" },
    { description: "BROCHURE", qty: "10", price: "$150", subtotal: "$1500" },
  ],
  emptyRowCount: 4,
  tax: "$340",
  grandTotal: "$4860",
  termsAndConditions:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent placerat vel sapien a ornare. Morbi faucibus nunc diam, in sodales nunc rutrum et. Aenean quis risus blandit, finibus lorem vitae, tincidunt purus.",
  contactEmail: "HELLO@REALLYGREATSITE.COM",
  contactPhone: "+123-456-7890",
  signerName: "OLIVIA WILSON",
  signerTitle: "GENERAL MANAGER",
};

interface InvoiceTemplateProps {
  data?: Partial<InvoiceData>;
}

export default function InvoiceTemplate({ data = {} }: InvoiceTemplateProps) {
  const invoice: InvoiceData = { ...defaultInvoice, ...data };
  const emptyRows = Array.from({ length: invoice.emptyRowCount ?? 4 });

  return (
    <div className="invoice-page">
      {/* Header */}
      <div className="invoice-header">
        <h1 className="invoice-title">INVOICE</h1>
        <div className="company-name">
          {invoice.companyName.split(" & ").map((part, i, arr) => (
            <span key={i}>
              {i === 0 ? part + (arr.length > 1 ? " &" : "") : part}
              <br />
            </span>
          ))}
        </div>
      </div>

      {/* Meta row: invoice info left, address right */}
      <div className="invoice-meta">
        <div className="invoice-meta-left">
          <p>INVOICE NUMBER: {invoice.invoiceNumber}</p>
          <p>DATE: {invoice.date}</p>
          <p>DUE DATE: {invoice.dueDate}</p>
        </div>
        <div className="invoice-meta-right">
          {invoice.companyAddressLines.map((line, i) => (
            <p key={i}>{line}</p>
          ))}
        </div>
      </div>

      {/* Bill To / Payment Method */}
      <div className="invoice-parties">
        <div className="bill-to">
          <h3>Bill To:</h3>
          <p className="name">{invoice.billTo.name}</p>
          <p>{invoice.billTo.address}</p>
          <p>{invoice.billTo.phone}</p>
        </div>
        <div className="payment-method">
          <h3>Payment Method</h3>
          <p>{invoice.paymentMethod.bankName}</p>
          <p className="name">{invoice.paymentMethod.accountName}</p>
          <p>{invoice.paymentMethod.phone}</p>
        </div>
      </div>

      {/* Table */}
      <table className="invoice-table">
        <thead>
          <tr>
            <th className="col-description">DESCRIPTION</th>
            <th className="col-qty">QTY</th>
            <th className="col-price">PRICE</th>
            <th className="col-subtotal">SUBTOTAL</th>
          </tr>
        </thead>
        <tbody>
          {invoice.items.map((item, i) => (
            <tr key={i}>
              <td className="col-description">{item.description}</td>
              <td className="col-qty">{item.qty}</td>
              <td className="col-price">{item.price}</td>
              <td className="col-subtotal">{item.subtotal}</td>
            </tr>
          ))}
          {emptyRows.map((_, i) => (
            <tr key={`empty-${i}`} className="empty-row">
              <td className="col-description">&nbsp;</td>
              <td className="col-qty">&nbsp;</td>
              <td className="col-price">&nbsp;</td>
              <td className="col-subtotal">&nbsp;</td>
            </tr>
          ))}
          <tr className="summary-row">
            <td colSpan={2} className="no-border" />
            <td className="summary-label">TAX</td>
            <td className="summary-value">{invoice.tax}</td>
          </tr>
          <tr className="summary-row">
            <td colSpan={2} className="no-border" />
            <td className="summary-label total-label">GRAND TOTAL</td>
            <td className="summary-value total-value">{invoice.grandTotal}</td>
          </tr>
        </tbody>
      </table>

      {/* Footer */}
      <div className="invoice-footer">
        <div className="terms">
          <h4>TERM &amp; CONDITION</h4>
          <p>{invoice.termsAndConditions}</p>
        </div>
        <div className="contact">
          <p>
            FOR ANY QUESTIONS, PLEASE CONTACT
            <br />
            {invoice.contactEmail}
            <br />
            OR {invoice.contactPhone}.
          </p>
        </div>
        <div className="signature">
          <div className="signature-line" />
          <p className="signer-name">{invoice.signerName}</p>
          <p className="signer-title">{invoice.signerTitle}</p>
        </div>
      </div>
    </div>
  );
}
